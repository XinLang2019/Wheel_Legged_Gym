This example is a test of Unitree G1/H1-2 robot.

**Note:** 
idl/unitree_go is used for Unitree Go2/B2/H1/B2w/Go2w robots
idl/unitree_hg is used for Unitree G1/H1-2 robots
