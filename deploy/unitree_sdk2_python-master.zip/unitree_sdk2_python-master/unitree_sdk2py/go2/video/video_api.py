"""
" service name
"""
VIDEO_SERVICE_NAME = "videohub"


"""
" service api version
"""
VIDEO_API_VERSION = "1.0.0.1"


"""
" api id
"""
VIDEO_API_ID_GETIMAGESAMPLE = 1001
