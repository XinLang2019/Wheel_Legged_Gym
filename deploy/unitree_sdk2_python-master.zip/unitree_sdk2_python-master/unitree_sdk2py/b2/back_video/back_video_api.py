"""
" service name
"""
ROBOT_BACK_VIDEO_SERVICE_NAME = "back_videohub"


"""
" service api version
"""
ROBOT_BACK_VIDEO_API_VERSION = "1.0.0.0"


"""
" api id
"""
ROBOT_BACK_VIDEO_API_ID_GETIMAGESAMPLE = 1001
